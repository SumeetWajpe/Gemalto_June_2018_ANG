var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 100; // Type Inference !
//x = "Hello !";
var str; // Type annotation !
var boolVar;
var y;
var arr;
var anyType;
anyType = 10;
anyType = "Hi";
anyType = { name: 'Typescript' };
function Add(x, y) {
    if (x < 0) {
        return 'x cannot be less than 0 !';
    }
    return x + y;
}
var result = Add(10, 20);
var cars = ['BMW', 'AUDI', 'FERRARI'];
var moreCars = new Array('TATA', "HYUNDAI", 'MAHINDRA');
for (var c in cars) {
    console.log(c); //??
}
// for-of
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var c = cars_1[_i];
    console.log(c);
}
cars.forEach(function (car, index) {
    console.log(car);
});
// Spread Operator !
var allCars = cars.concat(moreCars);
console.log(allCars);
/* Block scoped Variables */
var month = "May";
if (true) {
    var month_1 = "June";
    if (true) {
        console.log(month_1);
    }
}
var PI = 3.14;
// PI = 3.14665; // Error !
var person = { name: 'Sachin' };
person.name = "Virat";
/*  1. Optional */
// function PrintBooks(author?:string,title?:string,noOfPages?:number){
//         console.log(author,title,noOfPages)
// }
// PrintBooks();
// PrintBooks("Dr.APJ Abdul Kalam","India 2020",600);
function PrintBooks(author, title, noOfPages) {
    if (noOfPages === void 0) { noOfPages = 0; }
    console.log(author, title, noOfPages);
}
PrintBooks("Dr.APJ Abdul Kalam", "India 2020");
var Categories;
(function (Categories) {
    Categories[Categories["Inspirational"] = 0] = "Inspirational";
    Categories[Categories["Autobiography"] = 1] = "Autobiography";
    Categories[Categories["Fiction"] = 2] = "Fiction";
    Categories[Categories["Novel"] = 3] = "Novel";
})(Categories || (Categories = {}));
function GetAllBooks() {
    return [
        { name: 'India 2020', author: 'Dr. APJ Abdul Kalam', price: 400, available: true, category: Categories.Inspirational },
        { name: 'Wings Of Fire', author: 'Dr. APJ Abdul Kalam', price: 600, available: true, category: Categories.Inspirational },
        { name: 'Playing It My Way', author: 'Sachin Tendulkar', price: 900, available: true, category: Categories.Autobiography },
        { name: 'Cover Drive', author: 'Virat Kohli', price: 800, available: true, category: Categories.Autobiography }
    ];
}
var allBooks = GetAllBooks();
for (var _a = 0, allBooks_1 = allBooks; _a < allBooks_1.length; _a++) {
    var book = allBooks_1[_a];
    console.log('The Book ' + book.name + " is priced Rs." + book.price);
}
var Departments;
(function (Departments) {
    Departments[Departments["Training"] = 10] = "Training";
    Departments[Departments["Development"] = 11] = "Development";
    Departments[Departments["Testing"] = 12] = "Testing";
    Departments[Departments["Admin"] = 13] = "Admin";
})(Departments || (Departments = {}));
var dept = Departments.Training;
console.log(dept); // numeric
console.log(Departments[dept]); // string representation
function GetBooksByCategory(passedCategory) {
    var titles = [];
    for (var _i = 0, allBooks_2 = allBooks; _i < allBooks_2.length; _i++) {
        var currBook = allBooks_2[_i];
        if (currBook.category == passedCategory) {
            titles.push(currBook.name);
        }
    }
    ;
    return titles;
}
var AutobiographyBooks = GetBooksByCategory(Categories.Autobiography);
for (var _b = 0, AutobiographyBooks_1 = AutobiographyBooks; _b < AutobiographyBooks_1.length; _b++) {
    var b = AutobiographyBooks_1[_b];
    console.log(b);
}
var comp = { name: 'Gemalto',
    location: 'Noida',
    getDetails: function () {
    } };
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.Accelerate = function () {
        return this.name + " is running at " + this.speed + " kmph !";
    };
    return Car;
}());
// var carObj = new Car();
// carObj.Accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(n, s, fly, nitro) {
        var _this = _super.call(this, n, s) || this;
        _this.canFly = fly;
        _this.useNitro = nitro;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " , Can It Fly ? " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 400, true, true);
console.log(jbc.Accelerate());
var Human = /** @class */ (function () {
    function Human() {
    }
    return Human;
}());
var Person = /** @class */ (function (_super) {
    __extends(Person, _super);
    function Person() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Person.prototype.getDetails = function () {
        //console.log(this.name + " is of " + this.age + " years !");
        console.log(this.name + " is of " + this.age + " years !");
    };
    return Person;
}(Human));
// Enhanced Class Syntax
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        if (name === void 0) { name = "i10"; }
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
//var ec = new EnhancedCar();
// function Square(x){
//     return x * x;
// }
// var Square = function(x){
//     return x * x;
// }
// Arrow Functions
var Square = function (x) { return x * x; };
cars.forEach(function (car, index) {
    console.log(car);
});
cars.forEach(function (car, ind) { return console.log(car); });
function Emp() {
    var _this = this;
    this.Salary = 200000;
    setTimeout(function () {
        console.log(_this.Salary);
    }, 2000);
}
var e = new Emp();
