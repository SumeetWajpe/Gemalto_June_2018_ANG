let x:string = "Hello !";

const Pie = 3.14;

function Add(x:any,y:any){
    return x + y;
}