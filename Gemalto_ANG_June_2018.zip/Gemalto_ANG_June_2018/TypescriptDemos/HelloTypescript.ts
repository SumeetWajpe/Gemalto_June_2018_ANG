var x = 100; // Type Inference !
//x = "Hello !";

var str:string; // Type annotation !
var boolVar:boolean;
var y:number;
var arr:number[];
var anyType:any;
anyType = 10;
anyType = "Hi";
anyType = {name:'Typescript'};

function   Add(x:number,y:number):number|string{
    if(x < 0){
        return 'x cannot be less than 0 !';
    }
        return x + y;
}

var result:number|string = Add(10,20);


var cars:string[] = ['BMW','AUDI','FERRARI'];
var moreCars:Array<string> = new Array<string>('TATA',"HYUNDAI",'MAHINDRA');

for(var c in cars){
    console.log(c); //??
}

// for-of
for(var c of cars){
    console.log(c); 
}

cars.forEach(function(car,index){
        console.log(car);
});

// Spread Operator !
var allCars:string[] = [...cars,...moreCars];


console.log(allCars);


/* Block scoped Variables */
let month = "May";
if(true){
    let month="June";
    if(true){
        console.log(month);
    }
}

const PI:number = 3.14;
// PI = 3.14665; // Error !

const person ={name:'Sachin'};
person.name = "Virat";

/*  1. Optional */

// function PrintBooks(author?:string,title?:string,noOfPages?:number){
//         console.log(author,title,noOfPages)
// }

// PrintBooks();
// PrintBooks("Dr.APJ Abdul Kalam","India 2020",600);


function PrintBooks(author:string,title:string,noOfPages:number=0){
            console.log(author,title,noOfPages)
    }

    PrintBooks("Dr.APJ Abdul Kalam","India 2020");


    enum Categories{
        Inspirational,
        Autobiography,
        Fiction,
        Novel
    }


    interface IBook{
        name:string;
        author:string;
        available:boolean;
        category:Categories;
        price:number;
    }

    function GetAllBooks():IBook[]{
        return [
            {name:'India 2020',author:'Dr. APJ Abdul Kalam',price:400,available:true,category:Categories.Inspirational},
            {name:'Wings Of Fire',author:'Dr. APJ Abdul Kalam',price:600,available:true,category:Categories.Inspirational},
            {name:'Playing It My Way',author:'Sachin Tendulkar',price:900,available:true,category:Categories.Autobiography},
            {name:'Cover Drive',author:'Virat Kohli',price:800,available:true, category:Categories.Autobiography}
            
        ]
    }

    let allBooks:IBook[] = GetAllBooks();


    for(let book of allBooks){
        console.log('The Book ' + book.name + " is priced Rs." + book.price)
    }


    enum Departments{
        Training = 10,
        Development,
        Testing,
        Admin
    }

    var dept:Departments =  Departments.Training;

    console.log(dept); // numeric
    console.log(Departments[dept]);// string representation
    


function GetBooksByCategory(passedCategory:Categories):string[]{

    let titles:string[] = [];

    for(let currBook of allBooks){
        if(currBook.category == passedCategory){
            titles.push(currBook.name);
        }
    };
    return titles;
}

let AutobiographyBooks:string[] = 
GetBooksByCategory(Categories.Autobiography);

for(let b of AutobiographyBooks){
    console.log(b);
}


interface ICompany{
    name:string;
    location:string;
    isMNC?:boolean;
    getDetails?():void;
}

var comp:ICompany = {name:'Gemalto',
location:'Noida',
getDetails:function(){

}};

class Car{
    private id:number;
    name:string;
    speed:number;

    constructor(name:string="i20",speed:number=200){
            this.name = name;
            this.speed = speed;
    }
    Accelerate():string{
        return this.name +" is running at " + this.speed + " kmph !";
    }
}

// var carObj = new Car();
// carObj.Accelerate();


class JamesBondCar extends Car{
    canFly:boolean;
    useNitro:boolean;
    constructor(n:string,s:number,fly:boolean,nitro:boolean){
        super(n,s);
        this.canFly = fly;
        this.useNitro = nitro;
    }

    Accelerate():string{
            return super.Accelerate() +" , Can It Fly ? " + this.canFly;
    }
}

var jbc = new JamesBondCar("Houston",400,true,true);
console.log(jbc.Accelerate());


interface IPerson{
    name:string;
    age:number;
    getDetails?():void;
}

interface ITerrestrial{
        canWalk:boolean;
}


class Human{

}

class Person extends Human implements IPerson,ITerrestrial{
    name:string;
    canWalk:boolean;
    age:number;
    getDetails():void{
            //console.log(this.name + " is of " + this.age + " years !");
            console.log(`${this.name} is of ${this.age} years !`)
    }
}

// Enhanced Class Syntax

class EnhancedCar{
    
    constructor(public name:string="i10",public speed:number){
            
    }
}

//var ec = new EnhancedCar();

// function Square(x){
//     return x * x;
// }

// var Square = function(x){
//     return x * x;
// }


// Arrow Functions

var Square = (x:number) => x * x;


cars.forEach(function(car,index){
    console.log(car);
});

cars.forEach((car,ind)=>console.log(car));

function Emp(){
    
    this.Salary = 200000;
    setTimeout(()=>{
       console.log(this.Salary);

    },2000);
}

var e = new Emp();
