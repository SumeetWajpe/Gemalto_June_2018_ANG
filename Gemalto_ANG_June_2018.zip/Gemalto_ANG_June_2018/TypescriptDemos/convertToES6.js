var x = "Hello !";
var Pie = 3.14;
function Add(x, y) {
    return x + y;
}
