import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from
 '@angular/platform-browser/animations'

import { AppComponent } from './app.component';
import { CourseComponent } from './course/course.component';
import { ListCoursesComponent } from './list-courses/list-courses.component';


@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    ListCoursesComponent
  ],
  imports: [
    BrowserModule,BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
