import { Component, OnInit,Input } from '@angular/core';

import {
  trigger,
  state,
  style,
  transition,
  animate} from '@angular/animations';

@Component({
  selector: 'course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css'],
  animations:[
    trigger('animatedcourse',[
        state('inactive',style({
          backgroundColor:'grey',
          transform:'scale(1)'
        })),
        state('active',style({
          backgroundColor:'yellow',
          transform:'scale(1.1)'
        })),
        transition("inactive => active",animate('1000ms ease-in')),
        transition("active => inactive",animate('1000ms ease-out'))
    ])
]
})
export class CourseComponent implements OnInit {
 @Input() name:string="";
  state:string="inactive";
  constructor() { }

  ngOnInit() { }

  toggleActivate(){
    this.state = this.state === 'active' ? 'inactive' : 'active';
}
}
