import {Component,OnInit} from '@angular/core';



@Component({
        selector:`dashboard`,
        template: `        
        <h1> Dashboard </h1>
        <posts></posts>            
        ` 
           })
export class DashboardComponent {
    
    

}