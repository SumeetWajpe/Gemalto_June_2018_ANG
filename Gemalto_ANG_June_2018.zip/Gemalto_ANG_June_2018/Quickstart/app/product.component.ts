
import {Component,Input} from '@angular/core'
import { Product } from './product.model';

@Component({
selector:`product`,
template:`
<h2> {{prodDetails.name | uppercase | lowercase }} </h2>
<img [src]="prodDetails.ImageUrl" height="200px" width="200px"  /> <br/>      
<b> Price :  </b> {{prodDetails.price | currency:'INR':true }} <br/>
<b> Quantity :  </b> {{prodDetails.quantity | qty:'items'  }} <br/>                
<b> Rating :  </b> {{prodDetails.rating | number:'1.1-2' }} <br/> 
<b> RAW Data </b> {{prodDetails | json }}
 
`
})
export class ProductComponent{
     @Input()   prodDetails=new Product();       
    
}