"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n  <!--\n  <a routerLink=\"/posts\" class=\"btn btn-success\">Posts</a>\n  <a routerLink=\"/cart\" class=\"btn btn-success\">Shopping Cart</a>\n  -->\n  <router-outlet></router-outlet>"
        // template:`<posts></posts>`
        // template:`  <shoppingcart></shoppingcart>`
        //  template:`  <course></course>
        //  <course></course>`
    })
], AppComponent);
exports.AppComponent = AppComponent;
// import { Component } from '@angular/core';
// import {Course} from './course.model';
// @Component({
//   selector: 'my-app',
//   template:`
//   <shoppingcart></shoppingcart>`
//   // template: `
//   // <img src="{{imageUrl}}" height="200px" width="300px" />
//   // <img [src]="imageUrl" height="200px" width="300px" />
//   // <div>
//   // <p *ngFor="let c of courses">
//   //     <course [coursedetails]="c"></course>  
//   // </p>
//   // </div>    
//   // `,
// })
// export class AppComponent  {  
//   imageUrl:string="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVo30KgOnqmmcMgYIlYawpuMkHQkAUNoU6EtD-Tl2lekk9wmUp"
//   courses:Course[]=[
//     new Course("React",'3 Days'),
//     new Course("Node",'3 Days'),
//     new Course("C#",'5 Days'),
//     new Course("Redux",'2 Days')    
// ];
//  }
//# sourceMappingURL=app.component.js.map