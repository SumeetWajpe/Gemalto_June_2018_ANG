export class CourseService{
    listOfCourses:string[] = ['React','Node','C#']


    getAllCourses():string[]{
        return this.listOfCourses;
    }

    AddNewCourse(newCourse:string){
        this.listOfCourses.push(newCourse);
    }

    getRandomCourse():string{
        return this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)]
    }
}