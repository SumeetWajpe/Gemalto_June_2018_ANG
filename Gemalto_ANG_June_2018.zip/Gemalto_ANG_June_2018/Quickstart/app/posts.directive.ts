import {Directive, ElementRef,Input, OnInit, HostListener} from '@angular/core';

@Directive({
selector:`[postStyle]`
})
export class PostsDirective implements OnInit{

    @Input() inputColor="yellow"
    constructor(private elemRef:ElementRef){
       
    }

    ngOnInit(){        
        this.elemRef.nativeElement.style.backgroundColor = this.inputColor;
        this.elemRef.nativeElement.style.border = "2px solid red";
        this.elemRef.nativeElement.style.borderRadius = "5px";
        this.elemRef.nativeElement.style.margin = "10px";
        this.elemRef.nativeElement.style.padding = "10px";
        
        
        ;
        
    }

    @HostListener('mouseenter') CalledOnMouseEnter(){
        this.elemRef.nativeElement.style.backgroundColor = "yellow";
        this.elemRef.nativeElement.style.cursor = "pointer";
        // this.elemRef.nativeElement.style.transform = "scale(1.1)";
         this.elemRef.nativeElement.style.fontSize = "20px";
        
        
        // this.elemRef.nativeElement.children.append()

    }
    @HostListener('mouseleave') CalledOnMouseLeave(){
        this.elemRef.nativeElement.style.backgroundColor = this.inputColor;
        this.elemRef.nativeElement.style.cursor = "default";
        // this.elemRef.nativeElement.style.transform = "scale(1)";
        this.elemRef.nativeElement.style.fontSize = "14px";
        

    }


}