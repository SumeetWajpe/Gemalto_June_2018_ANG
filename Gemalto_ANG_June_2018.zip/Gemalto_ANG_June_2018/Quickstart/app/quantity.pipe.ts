import {Pipe, PipeTransform} from '@angular/core'
@Pipe({
    name:'qty'
})
export class QuantityPipe implements PipeTransform {
    transform(inputQty:number,theArgs:string){
            return inputQty + " " + theArgs;
    }
}