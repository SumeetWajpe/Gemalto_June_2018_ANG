import {Component,Input} from '@angular/core';
import { PostsService } from './posts.service';

@Component({
    selector:`posts`,   
    template: ` 
    <h1> Posts </h1>

    <ul>
    <li *ngFor="let p of allPosts" postStyle 
    inputColor="orange">
      <a routerLink="/post/{{p.id}}">  {{p.title}}  </a>
    </li>
    </ul>
     `,
    providers:[PostsService]
    })
export class PostsComponent{
    allPosts:any= [];
        // constructor(private servObj:PostsService){
        //     console.log('Calling GetPosts !');
        //     this.servObj.getPosts((responseFromService:any)=>{
        //          console.log('Within Component !');
        //         this.allPosts  = responseFromService;
        //     });
        //     //
        // }

        constructor(private servObj:PostsService){
           
         let thePromise =   this.servObj.getPosts();
         thePromise.then(
            (response)=>{ console.log(response.json()); 
                this.allPosts = response.json()
            
            localStorage["myposts"] = JSON.stringify(this.allPosts);
            },
            (err)=>{ console.log(err)}
         );

         console.log('Going ahead with execution !')
          
        }
}