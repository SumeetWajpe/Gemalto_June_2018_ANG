import {Component,Input} from '@angular/core';
import { CourseService } from './course.service';


@Component({
        selector:`course`,
        template: `        
                <h1> Courses </h1>

              New Course :   <input type="text" 
              [(ngModel)]="newCourse" />
              

              <input type="button" class="btn btn-primary" 
              (click)="AddCourse()" value="add Course"  />
              <input type="button" class="btn btn-primary" 
              (click)="GetCourse()" value="get Course"  /> <br/>
              {{receivedCourse}}   ` 
           })
export class CourseComponent{
        receivedCourse:string="";
        newCourse:string="";
constructor(private servObj:CourseService){
}
GetCourse(){
        this.receivedCourse = (this.servObj.getRandomCourse());
}
AddCourse(){
        this.servObj.AddNewCourse(this.newCourse);
}
}