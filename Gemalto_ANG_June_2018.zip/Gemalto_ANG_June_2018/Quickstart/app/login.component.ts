import {Component,OnInit} from '@angular/core';
import { UserService } from './user.service';
import { Router } from '@angular/router';



@Component({
        selector:`login-form`,
        template: `        
        <h1> Login </h1>
        <label>Username : </label>
        <form class="form-signin"
         (ngSubmit)="HandleFormSubmit()">         
          <div class="form-label-group">
            <input type="text" [(ngModel)]="inputName" 
            name="inputName" class="form-control" placeholder="Username" autofocus="">
            <label for="inputName">Username : </label>
          </div>
    
          <div class="form-label-group">
            <input type="password" [(ngModel)]="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required="">
            <label for="inputPassword">Password</label>
          </div>   
         
          <button class="btn btn-lg btn-primary"
           type="submit">Sign in</button>
    
        </form>

                    ` 
           })
export class LoginComponent {
  inputName:string="";
  inputPassword:string="";

  constructor(private userServObj:UserService,private route:Router){}    
  HandleFormSubmit(){
    if(this.inputName == "admin" && this.inputPassword == "admin"){
     this.userServObj.username ="admin";
      this.userServObj.setUserLoggedIn();// true
      // redirect him to dashboard
        this.route.navigate(['/dashboard']);
    }
  }
}