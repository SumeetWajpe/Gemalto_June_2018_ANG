"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Course = (function () {
    function Course(name, duration) {
        if (name === void 0) { name = "Angular"; }
        if (duration === void 0) { duration = "3 Days"; }
        this.name = name;
        this.duration = duration;
    }
    return Course;
}());
exports.Course = Course;
//# sourceMappingURL=course.model.js.map