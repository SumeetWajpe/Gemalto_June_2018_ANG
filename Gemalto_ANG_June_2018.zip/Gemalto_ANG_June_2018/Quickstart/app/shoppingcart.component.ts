
import {Component} from '@angular/core';
import {Product} from './product.model';
import { Form } from '@angular/forms';

@Component({
selector:`shoppingcart`,
templateUrl:`./app/shoppingcart.template.html`,
styleUrls:['./app/product.style.css']
})
export default class ShoppingCartComponent{   
    isActive:boolean=false;   
    newProduct:Product = new Product();
    companyName:string="";
    productToBeSearched:string="";
    heading:string="Shopping Cart";
     products:Product[] = [    new Product('Laptop',40000,30,3,'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70'),
        new Product('LED TV',50000,20,3,'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg'),
        new Product('Desktop',20000,40,3,'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg'),
        new Product('Mobile',30000,50,3,'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg'),
        new Product('Camera',50000,100,3,'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png')
             ];    
             ChangeHeading(){                
                this.heading = "Walmart !"
             }

             AddProduct(theForm:any){
                 // ???

                 if(theForm.valid){
                    this.products.push(this.newProduct);
                    this.newProduct = new Product();
                    theForm.reset();
                 }
             
             }

      
}

