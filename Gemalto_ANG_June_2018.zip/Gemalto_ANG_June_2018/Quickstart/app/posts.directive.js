"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var PostsDirective = (function () {
    function PostsDirective(elemRef) {
        this.elemRef = elemRef;
        this.inputColor = "yellow";
    }
    PostsDirective.prototype.ngOnInit = function () {
        this.elemRef.nativeElement.style.backgroundColor = this.inputColor;
        this.elemRef.nativeElement.style.border = "2px solid red";
        this.elemRef.nativeElement.style.borderRadius = "5px";
        this.elemRef.nativeElement.style.margin = "10px";
        this.elemRef.nativeElement.style.padding = "10px";
        ;
    };
    PostsDirective.prototype.CalledOnMouseEnter = function () {
        this.elemRef.nativeElement.style.backgroundColor = "yellow";
        this.elemRef.nativeElement.style.cursor = "pointer";
        // this.elemRef.nativeElement.style.transform = "scale(1.1)";
        this.elemRef.nativeElement.style.fontSize = "20px";
        // this.elemRef.nativeElement.children.append()
    };
    PostsDirective.prototype.CalledOnMouseLeave = function () {
        this.elemRef.nativeElement.style.backgroundColor = this.inputColor;
        this.elemRef.nativeElement.style.cursor = "default";
        // this.elemRef.nativeElement.style.transform = "scale(1)";
        this.elemRef.nativeElement.style.fontSize = "14px";
    };
    return PostsDirective;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], PostsDirective.prototype, "inputColor", void 0);
__decorate([
    core_1.HostListener('mouseenter'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PostsDirective.prototype, "CalledOnMouseEnter", null);
__decorate([
    core_1.HostListener('mouseleave'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PostsDirective.prototype, "CalledOnMouseLeave", null);
PostsDirective = __decorate([
    core_1.Directive({
        selector: "[postStyle]"
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], PostsDirective);
exports.PostsDirective = PostsDirective;
//# sourceMappingURL=posts.directive.js.map