import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';

import {CourseComponent} from './course.component'
import { AppComponent }  from './app.component';
import ShoppingCartComponent from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { QuantityPipe } from './quantity.pipe';
import { CourseService } from './course.service';
import { PostsComponent } from './posts.component';
import { PostsDirective } from './posts.directive';
import {Routes,RouterModule } from '@angular/router';
import { PostDetailsComponent } from './post.details.component';
import { LoginComponent } from './login.component';
import { DashboardComponent } from './dashboard.component';
import { UserService } from './user.service';
import { AuthGaurd } from './auth.gaurd.service';


// let routes:Routes = [
//     {path:'posts',component:PostsComponent},
//     {path:'cart',component:ShoppingCartComponent} ,
//     {path:'post/:id',component:PostDetailsComponent} ,
    
//     {path:'',redirectTo:'/posts',pathMatch:"full"},
//     {path:'**',redirectTo:'/cart',pathMatch:"full"}    
//     // {path:'**',component:ErrorComponent}   
       
      
// ];


let routes:Routes = [ 
  {path:'',component:LoginComponent},
  {
    path:'dashboard',
  component:DashboardComponent,
  canActivate:[AuthGaurd]
},
  
];


@NgModule({
  imports:      [ BrowserModule,FormsModule,
    HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,CourseComponent,
    ShoppingCartComponent,QuantityPipe,
    ProductComponent,PostsComponent,PostsDirective,
    PostDetailsComponent,LoginComponent,DashboardComponent ],
  bootstrap:    [ AppComponent ]
  ,
        providers:[CourseService,UserService,
          AuthGaurd]
})
export class AppModule { }
