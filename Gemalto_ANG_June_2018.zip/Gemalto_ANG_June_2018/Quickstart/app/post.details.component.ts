import {Component,OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';



@Component({
        selector:`postdetails`,
        template: `        
                <h1> Post Details for {{postId}} </h1>
                <b> Id : </b> {{theReceivedPost.id}} <br/>
                <b> Title: </b> {{theReceivedPost.title}} <br/>
                <b>Body : </b> {{theReceivedPost.body}}
             ` 
           })
export class PostDetailsComponent implements OnInit{
    
    postId:number;
    theReceivedPost:any;
    constructor(private currRoute:ActivatedRoute){}

        ngOnInit(){
            this.currRoute.params.subscribe(
                p=>{
                        this.postId = p["id"];
                        let allPosts = JSON.parse(localStorage["myposts"])
                        // find the post from the array
                        this.theReceivedPost = allPosts.find(
                            (post:any) =>{
                                return post.id == this.postId
                            }
                        )
                            // localStorage.clear();
                       
                        
                }
            )



        }
}