import { CanActivate, Router } from "@angular/router";
import { UserService } from "./user.service";
import { Injectable } from "@angular/core";


@Injectable()
export class AuthGaurd implements CanActivate{

    constructor(private userObj:UserService,private router:Router){}
    canActivate():boolean{
        //Logged - In ??
        if(!this.userObj.getUserLoggedIn()){
                this.router.navigate(['/']);
        }

        return this.userObj.getUserLoggedIn();
    }
}