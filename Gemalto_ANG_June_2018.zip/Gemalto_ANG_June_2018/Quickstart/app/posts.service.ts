import {Http} from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{
   constructor(private httpObj:Http){   
}
getPosts(){
    // make an ajax request here !
   return this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
}

// getPosts(callBackFunc:any){
//     // make an ajax request here !
//     this.httpObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(response){
//         callBackFunc(response.json());// invoke the function !
//     })
// }
}