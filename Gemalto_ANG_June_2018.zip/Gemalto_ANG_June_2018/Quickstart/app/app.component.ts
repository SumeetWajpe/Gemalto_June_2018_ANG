import { Component } from '@angular/core';
import {Course} from './course.model';

@Component({
  selector: 'my-app',
  template:`
  <!--
  <a routerLink="/posts" class="btn btn-success">Posts</a>
  <a routerLink="/cart" class="btn btn-success">Shopping Cart</a>
  -->
  <router-outlet></router-outlet>`
  // template:`<posts></posts>`
 // template:`  <shoppingcart></shoppingcart>`
//  template:`  <course></course>
//  <course></course>`
 
})
export class AppComponent  {  
  

 }






 

// import { Component } from '@angular/core';
// import {Course} from './course.model';

// @Component({
//   selector: 'my-app',
//   template:`
//   <shoppingcart></shoppingcart>`
//   // template: `


//   // <img src="{{imageUrl}}" height="200px" width="300px" />
//   // <img [src]="imageUrl" height="200px" width="300px" />

//   // <div>
//   // <p *ngFor="let c of courses">
//   //     <course [coursedetails]="c"></course>  
//   // </p>
//   // </div>    
//   // `,
// })
// export class AppComponent  {  

//   imageUrl:string="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVo30KgOnqmmcMgYIlYawpuMkHQkAUNoU6EtD-Tl2lekk9wmUp"
//   courses:Course[]=[
//     new Course("React",'3 Days'),
//     new Course("Node",'3 Days'),
//     new Course("C#",'5 Days'),
//     new Course("Redux",'2 Days')    
// ];


  

//  }
